<?php

/**
 * @file
 * guide to local plugin's API
 */

/**
 * Form submission callback for the slideshow settings.
 */
function hook_views_highcharts_options_form_submit($form, &$form_state) {
  // Act on option submission.
}

